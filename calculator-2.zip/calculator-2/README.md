
#  🧮CALCULATOR 

1) This is  a basic calculator application developed by using **CSS, HTML, and JavaScript**.

2) It has an interactive interface with buttons for addition, subtraction, multiplication, and division operations.

3) The calculator has a display screen to show user input and results by utilizing CSS grid system for button alignments.
## Demo

https://coder-rajora.github.io/CODESOFT-Task-3-Calculator/
## Screenshots

![Calculator ss](https://github.com/coder-rajora/CODESOFT-Task-3-Calculator/assets/91421022/a5eeb564-e5c0-4bb5-863a-f9b078482727)



## Author

- [Rishabh Rajora](https://github.com/coder-rajora)

